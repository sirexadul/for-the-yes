plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.yeswidget"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.yeswidget"
        minSdk = 21
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
// No dependencies on purpose: smallest possible APK.
